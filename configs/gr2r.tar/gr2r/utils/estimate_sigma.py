import torch
import torch.nn.functional as F

def estimate_sigma_mad(img_sub):
    """
    Robust Noise Level Estimation using MAD (Median Absolute Deviation)
    입력: PD가 적용된 Sub-image (B*s^2, C, H/s, W/s) - 노이즈가 독립적이라고 가정
    출력: 추정된 Sigma 값 (B,)
    """
    # 1. 고주파 성분 추출 (High-pass filtering)
    # 이미지의 텍스처를 배제하고 노이즈만 남기기 위해 인접 픽셀과 뺄셈을 합니다.
    # (B, C, H, W-1)
    diff = img_sub[..., 1:] - img_sub[..., :-1] 
    
    # 2. MAD 계산
    # 공식: sigma = median(|x - median(x)|) / 0.6745
    # 정규분포(Gaussian) 가정 하에 표준편차의 근사값을 구합니다.
    
    # 배치를 제외한 나머지 차원으로 평탄화 (B, -1)
    diff_flat = diff.view(diff.size(0), -1)
    
    # 중앙값(Median) 계산 (각 배치별로)
    median_val = torch.median(diff_flat, dim=1, keepdim=True).values
    
    # 편차의 절댓값의 중앙값
    mad = torch.median(torch.abs(diff_flat - median_val), dim=1).values
    
    # 정규분포 상수(0.6745)로 보정하여 Sigma 도출
    sigma_est = mad / 0.6745
    
    return sigma_est

def estimate_sigma_mad_map(img, stride=2):
    """
    Robust Noise Level Map Estimation using MAD (Spatially Local)
    
    [수정 사항]
    입력: 원본 해상도 이미지 (B, C, H, W)
    출력: 추정된 Sigma Map (B, C, H, W) - 입력과 동일한 크기로 복원됨
    """
    b, c, h, w = img.shape

    # 1. 이웃 픽셀 모으기 (Unfold / Pixel Unshuffle)
    # (B, C, H, W) -> (B, C, H//s, s, W//s, s)로 차원을 쪼갭니다.
    # 이렇게 해야 H와 W를 stride로 나눈 '패치' 개념이 생깁니다.
    img_unfolded = img.view(b, c, h // stride, stride, w // stride, stride)

    # 2. 이웃끼리 마지막 차원으로 몰아넣기
    # (B, C, H//s, W//s, s, s) -> (B, C, H//s, W//s, s*s)
    # 이제 마지막 차원(dim=-1)에 4개(stride=2일 때)의 이웃 픽셀이 모입니다.
    img_neighbors = img_unfolded.permute(0, 1, 2, 4, 3, 5).reshape(b, c, h // stride, w // stride, stride**2)

    # 3. 이웃 간의 MAD 계산 (Local Estimation)
    
    # 이웃들의 중앙값 (Signal 추정) -> dim=-1 기준
    median_val = torch.median(img_neighbors, dim=-1, keepdim=True).values
    
    # (값 - 중앙값)의 절댓값
    diff = torch.abs(img_neighbors - median_val)
    
    # MAD 계산 (중앙값의 중앙값)
    mad = torch.median(diff, dim=-1, keepdim=True).values
    
    # 4. Sigma 도출
    # (B, C, H//s, W//s, 1) -> (B, C, H//s, W//s)
    sigma_low_res = (mad / 0.6745).squeeze(-1)

    # 5. 원래 해상도로 복원 (Upsample)
    # (B, C, H//s, W//s) -> (B, C, H, W)
    # Nearest로 늘려야 '패치 단위'의 노이즈 레벨이 유지됩니다.
    sigma_map = F.interpolate(sigma_low_res, size=(h, w), mode='nearest')
    
    return sigma_map

# def estimate_smart_sigma(y, mad_factor=1.0, edge_sensitivity=5.0):
#     """
#     엣지(글자/텍스처)를 감지해서 그 부분만 Sigma를 낮추는 함수
#     입력: y (B, C, H, W) - 원본 이미지
#     출력: sigma_map (B, C, H, W)
#     """
#     # 1. 베이스: MAD로 노이즈 맵 추정
#     # 위에서 수정한 함수를 호출하므로, 입력 y를 그대로 넣으면 됩니다.
#     sigma_base = estimate_sigma_mad_map(y) 
    
#     # (옵션) MAD가 너무 불안정하다 싶으면 아래 줄 주석 해제하여 상수로 테스트
#     # sigma_base = torch.full_like(y, 0.03)

#     # 2. 엣지 검출 (Sobel Filter)
#     # 가로/세로 방향의 변화량을 감지하여 '글자'를 찾아냅니다.
#     k_x = torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], device=y.device).float().view(1, 1, 3, 3)
#     k_y = torch.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], device=y.device).float().view(1, 1, 3, 3)
    
#     # 채널별로 엣지 강도 계산
#     edge_x = F.conv2d(y, k_x.repeat(y.shape[1], 1, 1, 1), padding=1, groups=y.shape[1])
#     edge_y = F.conv2d(y, k_y.repeat(y.shape[1], 1, 1, 1), padding=1, groups=y.shape[1])
#     edge_mag = torch.sqrt(edge_x**2 + edge_y**2 + 1e-6)
    
#     # 3. 마스크(Weight) 생성
#     # 엣지가 강한 곳(큰 값) -> weight는 0에 수렴 (Sigma 삭제)
#     # 엣지가 없는 곳(0) -> weight는 1에 수렴 (Sigma 유지)
#     # edge_sensitivity 값을 키울수록(10.0 등) 글자를 더 강력하게 보호합니다.
#     weight = torch.exp(-edge_mag * edge_sensitivity) 
    
#     # 4. 최종 맵 생성
#     # 글자 부분은 노이즈 레벨을 거의 0으로 만들어서 보존합니다.
#     sigma_final = sigma_base * weight
    
#     # 최소한의 노이즈(0.001)는 남겨서 수치 안정성(Division by zero 방지 등) 확보
#     return sigma_final.clamp(min=0.001)


# def estimate_smart_sigma(y, base_sigma=0.08, edge_sensitivity=2.0):
#     """
#     [최종 추천 버전] 
#     엣지(글자)는 보호하면서, R2R 학습에 필요한 최적의 노이즈(base_sigma=0.15)를 주입합니다.
#     """
#     # 1. 든든한 베이스 노이즈 설정 (PSNR 19dB 타겟)
#     sigma_base = torch.full_like(y, base_sigma)

#     # 2. 강한 블러링 (Smoothing) 선행 🔥 (가장 중요한 핵심!)
#     # SIDD의 지글거리는 노이즈를 엣지로 착각하지 않도록 커널을 5로 키워 미리 뭉갭니다.
#     y_smoothed = F.avg_pool2d(y, kernel_size=5, stride=1, padding=2)

#     # 3. 엣지 검출 (Sobel) - 뭉개진 이미지 위에서 진짜 글자 테두리만 찾습니다.
#     k_x = torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], device=y.device).float().view(1, 1, 3, 3)
#     k_y = torch.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], device=y.device).float().view(1, 1, 3, 3)
    
#     edge_x = F.conv2d(y_smoothed, k_x.repeat(y.shape[1], 1, 1, 1), padding=1, groups=y.shape[1])
#     edge_y = F.conv2d(y_smoothed, k_y.repeat(y.shape[1], 1, 1, 1), padding=1, groups=y.shape[1])
#     edge_mag = torch.sqrt(edge_x**2 + edge_y**2 + 1e-6)

#     # 4. 마스크 생성
#     # edge_sensitivity를 2.0으로 낮춰서 방어막이 너무 넓게 퍼져 노이즈를 다 지워버리는 것을 막습니다.
#     weight = torch.exp(-edge_mag * edge_sensitivity)

#     # 5. 최종 시그마 맵
#     # 엣지 부분이라도 최소 0.02의 노이즈는 보장하여 완전 0이 되는 것을 방어합니다.
#     sigma_final = sigma_base * weight
#     return sigma_final.clamp(min=0.02)

def estimate_smart_sigma(y, window_size=7, edge_sensitivity=1.0):
    """
    Self-supervised 상황에서 입력 이미지 y의 공간적 노이즈 레벨(sigma map)을 추정합니다.
    
    Args:
        y (Tensor): 입력 노이즈 이미지 (B, C, H, W)
        window_size (int): 국소 노이즈를 추정할 윈도우 크기 (보통 5 또는 7)
        edge_sensitivity (float): 엣지 영역의 과대 추정을 방지하기 위한 민감도 조절 파라미터
    Returns:
        sigma_map (Tensor): 픽셀별 노이즈 레벨이 추정된 맵 (B, C, H, W)
    """
    B, C, H, W = y.shape
    
    # 1. Laplacian 필터로 저주파(구조적 배경) 제거 및 고주파(노이즈+엣지) 추출
    # 표준 3x3 라플라시안 커널 적용
    laplacian_kernel = torch.tensor([[ 1.,  2.,  1.],
                                     [ 2., -12., 2.],
                                     [ 1.,  2.,  1.]], device=y.device, dtype=y.dtype)
    # (Out_C, In_C/groups, kH, kW) 형태로 변환
    laplacian_kernel = laplacian_kernel.view(1, 1, 3, 3).repeat(C, 1, 1, 1)
    
    # 패딩을 주어 크기 유지 (groups=C 로 채널별 독립 연산)
    high_freq = F.conv2d(y, laplacian_kernel, padding=1, groups=C)
    
    # 2. 국소 영역의 분산(Variance) 추정
    # high_freq의 제곱을 구한 뒤, window_size 만큼 Average Pooling을 하여 국소 분산을 구함
    local_variance = F.avg_pool2d(high_freq ** 2, kernel_size=window_size, stride=1, padding=window_size//2)
    
    # 3. 라플라시안 필터의 통계적 보정 계수 적용
    # 라플라시안 커널을 통과한 가우시안 노이즈의 분산은 원래 분산의 약 34배(위 커널 기준)가 됨
    # 이를 역산하여 원래의 sigma 값을 복원 (수학적 증명 기반)
    # 상수 보정 (엣지에서의 과대 추정을 edge_sensitivity로 조절)
    correction_factor = 34.0 * edge_sensitivity 
    
    # 분산에서 표준편차(sigma)로 변환
    sigma_map = torch.sqrt(torch.clamp(local_variance / correction_factor, min=1e-8))

    # 각 이미지의 전반적인 베이스라인 노이즈(중간값) 추출
    global_median = torch.median(sigma_map.view(B, -1), dim=1).values
    global_median = global_median.view(B, 1, 1, 1)

    # 글씨(Edge) 영역의 과도한 sigma 값을 베이스라인의 1.5배로 제한
    sigma_map = torch.clamp(sigma_map, max=global_median * 1.5)
    
    return sigma_map