from __future__ import annotations
import argparse
from pathlib import Path
from typing import Optional, Dict, Any

import numpy as np
import random
import matplotlib.pyplot as plt
import wandb

import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader

import lightning as L
from lightning.pytorch.callbacks import ModelCheckpoint
from lightning.pytorch.loggers import WandbLogger

from torchmetrics.image import PeakSignalNoiseRatio, StructuralSimilarityIndexMeasure

from .datasets.div2k import DIV2KPairs
from .datasets.sidd import SIDDTrainDataset, SIDDValidationDataset
from .models.autoencoder import Autoencoder
from .models.dncnn import DnCNN
from .models.drunet import DRUNet
from .models.unet import UNet
from .utils.noise import get_noise_fns
from .utils.transform import build_transforms
from .utils.pixel_downsampling import pixel_unshuffle, pixel_shuffle


def load_init_weights(model: torch.nn.Module, ckpt_path: str, strict: bool = True) -> None:
    """
    Load initial weights ONLY (no optimizer/scheduler/scaler).
    Supports:
      - plain state_dict (.pth/.pt)  (keys match model)
      - lightning checkpoint (.ckpt) (state_dict keys like "model.xxx" or "xxx")
    """
    ckpt = torch.load(ckpt_path, map_location="cpu")

    # case A) lightning ckpt
    if isinstance(ckpt, dict) and "state_dict" in ckpt:
        sd = ckpt["state_dict"]
    # case B) common wrappers
    elif isinstance(ckpt, dict) and "model" in ckpt:
        sd = ckpt["model"]
    else:
        sd = ckpt

    # strip common prefixes
    new_sd = {}
    for k, v in sd.items():
        if k.startswith("model."):
            new_sd[k[len("model."):]] = v
        elif k.startswith("module."):
            new_sd[k[len("module."):]] = v
        else:
            new_sd[k] = v

    missing, unexpected = model.load_state_dict(new_sd, strict=strict)
    if len(missing) or len(unexpected):
        print(f"[init_weights] missing={len(missing)}, unexpected={len(unexpected)}")
        if len(missing):
            print("  missing keys (first 20):", missing[:20])
        if len(unexpected):
            print("  unexpected keys (first 20):", unexpected[:20])


def build_model(model_name: str) -> torch.nn.Module:
    m = model_name.lower()
    if m == "autoencoder":
        return Autoencoder(in_ch=3, base=32)
    if m == "dncnn":
        # DnCNN: input/output same channels
        return DnCNN(in_channels=3, out_channels=3, depth=20, nf=64, bias=True)
    if m == "drunet":
        # DRUNet expects sigma channel inside; we pass sigma via forward(x, sigma=...)
        return DRUNet(in_channels=3, out_channels=3)
    if m == "unet":
        return UNet(in_channels=3, out_channels=3)
    raise ValueError(f"Unknown model: {model_name} (choose from autoencoder|dncnn|drunet)")

def estimate_sigma_mad(img_sub):
    """
    Robust Noise Level Estimation using MAD (Median Absolute Deviation)
    입력: PD가 적용된 Sub-image (B*s^2, C, H/s, W/s) - 노이즈가 독립적이라고 가정
    출력: 추정된 Sigma 값 (B,)
    """
    # 1. 고주파 성분 추출 (High-pass filtering)
    # 이미지의 텍스처를 배제하고 노이즈만 남기기 위해 인접 픽셀과 뺄셈을 합니다.
    # (B, C, H, W-1)
    diff = img_sub[..., 1:] - img_sub[..., :-1] 
    
    # 2. MAD 계산
    # 공식: sigma = median(|x - median(x)|) / 0.6745
    # 정규분포(Gaussian) 가정 하에 표준편차의 근사값을 구합니다.
    
    # 배치를 제외한 나머지 차원으로 평탄화 (B, -1)
    diff_flat = diff.view(diff.size(0), -1)
    
    # 중앙값(Median) 계산 (각 배치별로)
    median_val = torch.median(diff_flat, dim=1, keepdim=True).values
    
    # 편차의 절댓값의 중앙값
    mad = torch.median(torch.abs(diff_flat - median_val), dim=1).values
    
    # 정규분포 상수(0.6745)로 보정하여 Sigma 도출
    sigma_est = mad / 0.6745
    
    return sigma_est

class CharbonnierLoss(torch.nn.Module):
    def __init__(self, eps=1e-3):
        super(CharbonnierLoss, self).__init__()
        self.eps = eps

    def forward(self, x, y):
        diff = x - y
        # L1과 비슷하지만 미분 가능 (sqrt(x^2 + eps^2))
        loss = torch.sqrt(diff * diff + self.eps * self.eps)
        return torch.mean(loss)

def extract_grid_pattern(image, stride=2):
    """
    이미지에서 격자 패턴(Artifact)만 추출하여 반환
    """
    b, c, h, w = image.shape
    unshuffled = image.view(b, c, h // stride, stride, w // stride, stride)
    local_mean = unshuffled.mean(dim=(3, 5), keepdim=True)
    deviation = unshuffled - local_mean
    
    # 편차에서 텍스처 제거하고 격자만 남김 (Low Pass Filter)
    dev_flat = deviation.permute(0, 1, 3, 5, 2, 4).reshape(-1, 1, h // stride, w // stride)
    n_grid_flat = F.avg_pool2d(dev_flat, kernel_size=3, stride=1, padding=1)
    
    # 격자 패턴 복원
    n_grid = n_grid_flat.view(b, c, stride, stride, h // stride, w // stride).permute(0, 1, 4, 2, 5, 3)
    n_grid_full = n_grid.reshape(b, c, h, w)
    
    return n_grid_full


class PD_GR2R(L.LightningModule):
    def __init__(
        self,
        model_name: str,
        distribution: str,
        noise_level: float,
        stride: int,
        alpha: float,
        lr: float,
        loss_type: str,
        max_epochs: int,
        mc_samples: int,
        sigma_mode: str = "noise_level",   # how to set sigma for DRUNet: noise_level or fixed
        sigma_value: float = 0.1,          # used when sigma_mode="fixed"
    ):
        super().__init__()
        self.save_hyperparameters()

        self.model = build_model(model_name=model_name)

        # GR2R corruptor depends on distribution
        self.add_noise, self.corruptor = get_noise_fns(distribution)
        self.stride = stride

        self.psnr = PeakSignalNoiseRatio(data_range=1.0)
        self.ssim = StructuralSimilarityIndexMeasure(data_range=1.0)

        self.cbl_loss = CharbonnierLoss()

    def configure_optimizers(self):
        optimizer = torch.optim.AdamW(self.parameters(), lr=self.hparams.lr)
        step_size = int(self.hparams.max_epochs * 0.8) + 1

        # scheduler = torch.optim.lr_scheduler.StepLR(
        #     optimizer, 
        #     step_size=step_size, 
        #     gamma=0.1 # LR을 1/10로 줄임 (일반적인 세팅)
        # )

        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer,
            T_max=self.hparams.max_epochs,  # 예: 100
            eta_min=1e-6  # 최소 LR (0이 되지 않게 안전장치)
        )
        
        return [optimizer], [scheduler]
    
    def forward(self, x: torch.Tensor, sigma_map=None):
        # ==========================================================
        # [수정] Zero-Padding Artifact 방지 (Ghosting 해결 핵심)
        # ==========================================================
        # 모델(DnCNN 등)이 3x3 Conv를 쓸 때 테두리에 0을 채우는데,
        # PD로 쪼개진 이미지에서는 이 테두리가 나중에 합쳐질 때 
        # 이미지 정중앙에 '검은 격자'나 '위치 어긋남'을 만듭니다.
        # 이를 막기 위해 입력 이미지를 미리 거울처럼 반사(Reflect)해서 넓혀줍니다.
        
        pad_size = 2  # 8픽셀 정도면 충분합니다 (Receptive Field 고려)
        x_pad = F.pad(x, (pad_size, pad_size, pad_size, pad_size), mode='reflect')

        # ----------------------------------------------------------
        # 기존 로직 (Sigma 처리 등)
        # ----------------------------------------------------------
        # 1. DRUNet이 아니면 Sigma 필요 없음
        if self.hparams.model_name.lower() != "drunet":
            out_pad = self.model(x_pad)
        else:
            # 2. Sigma 값 결정
            if sigma_map is not None:
                sigma = sigma_map
            else:
                if self.hparams.sigma_mode == "fixed":
                    sigma_val = float(self.hparams.sigma_value)
                else:
                    sigma_val = float(self.hparams.noise_level)
                sigma = torch.full((x.size(0),), sigma_val, device=x.device, dtype=x.dtype)

            # 3. 차원 불일치 자동 보정 (x_pad 사이즈 기준)
            if isinstance(sigma, torch.Tensor) and sigma.ndim == 1:
                # x가 PD로 인해 배치가 늘어났는데 sigma가 원본 배치 사이즈라면
                if x_pad.size(0) != sigma.size(0):
                    if x_pad.size(0) > sigma.size(0) and x_pad.size(0) % sigma.size(0) == 0:
                        repeat_factor = x_pad.size(0) // sigma.size(0)
                        sigma = sigma.repeat_interleave(repeat_factor)
            
            out_pad = self.model(x_pad, sigma=sigma)

        # ==========================================================
        # [복구] 아까 붙였던 패딩만큼 다시 잘라내기 (Center Crop)
        # ==========================================================
        out = out_pad[..., pad_size:-pad_size, pad_size:-pad_size]
        
        return out

    def r2r_loss(self, 
                 pred: torch.Tensor, 
                 target: torch.Tensor) -> torch.Tensor:
        if self.hparams.loss_type == "mse":
            loss = torch.nn.functional.mse_loss(pred, target)

        elif self.hparams.loss_type == "cbl":
            loss = self.cbl_loss(pred, target)

        elif self.hparams.loss_type == "nll":
            mu, log_var = torch.chunk(pred, 2, dim=1)
            log_var = torch.clamp(log_var, min=-10, max=10)
            var = torch.exp(log_var)

            loss = torch.nn.functional.gaussian_nll_loss(mu, target, var, reduction='mean')

        return loss

    def training_step(self, batch, batch_idx):
        # 1. Clean GT
        x = batch["x"] 
        b_size = x.size(0)

        noisy_images = []
        # 배치 내 이미지마다 서로 다른 sigma를 가질 수 있도록 랜덤값 생성
        sigma_vals = (torch.rand(b_size, device=self.device) * (0.2 - 0.01)) + 0.01

        for i in range(b_size):
            # 1. 개별 이미지와 개별 Sigma 추출
            img_clean = x[i]  # (C, H, W)
            sigma = sigma_vals[i].item() # Tensor -> float 변환 (함수가 float를 원함)
            
            # 2. 박사님의 함수 호출 (함수 수정 X)
            # 함수 내부에서 3차원 입력도 알아서 처리해줍니다.
            img_noisy = self.add_noise(img_clean, sigma) # (C, H, W)
            
            noisy_images.append(img_noisy)
        
        # 3. 다시 하나의 배치로 합치기 (Stack)
        y = torch.stack(noisy_images, dim=0) # (B, C, H, W)

        # 4. Model Forward (PD 적용)
        y_sub = pixel_unshuffle(y, self.stride)
        sigma_input = sigma_vals.view(b_size, -1)
        
        output_sub = self.forward(y_sub.clamp(0, 1), sigma_input)
                   
        pred = pixel_shuffle(output_sub, self.stride)

        # 5. Loss (Only L1)
        # : 기교 없이 정답과 비교. 가장 선명한 결과를 얻음.
        loss = self.r2r_loss(pred, x)
        
        self.log("train_loss", loss, prog_bar=True)
        return loss

    @torch.no_grad()
    def validation_step(self, batch, batch_idx):
        # 1. Clean GT
        x = batch["x"] 
        b_size = x.size(0)

        # 2. Noise Level 결정 (Deterministic)
        # : 검증 때는 매번 똑같은 노이즈로 평가해야 공정하므로 
        #   batch_idx를 시드로 고정합니다.
        rng = torch.Generator(device=self.device)
        rng.manual_seed(int(batch_idx)) 
        
        noisy_images = []
        # 배치 내 이미지마다 서로 다른 sigma를 가질 수 있도록 랜덤값 생성
        sigma_vals = (torch.rand(b_size, device=self.device) * (0.2 - 0.01)) + 0.01

        for i in range(b_size):
            # 1. 개별 이미지와 개별 Sigma 추출
            img_clean = x[i]  # (C, H, W)
            sigma = sigma_vals[i].item() # Tensor -> float 변환 (함수가 float를 원함)
            
            # 2. 박사님의 함수 호출 (함수 수정 X)
            # 함수 내부에서 3차원 입력도 알아서 처리해줍니다.
            img_noisy = self.add_noise(img_clean, sigma) # (C, H, W)
            
            noisy_images.append(img_noisy)
        
        # 3. 다시 하나의 배치로 합치기 (Stack)
        y = torch.stack(noisy_images, dim=0) # (B, C, H, W)

        # 4. Model Forward
        # : Recorruption 없이 바로 모델에 넣습니다.
        y_sub = pixel_unshuffle(y, 2)
        sigma_input = sigma_vals.view(b_size, -1)
        
        output_sub = self.forward(y_sub.clamp(0, 1), sigma_input)
            
        pred = pixel_shuffle(output_sub, 2)
        pred = torch.clamp(pred, 0.0, 1.0)

        # 5. 평가 (Clean x와 비교)
        # : PSNR이 가장 확실한 지표입니다.
        val_psnr = self.psnr(pred, x)
        val_ssim = self.ssim(pred, x)
        
        self.log("val_psnr", val_psnr, prog_bar=True, on_step=False, on_epoch=True)
        self.log("val_ssim", val_ssim, prog_bar=False, on_step=False, on_epoch=True)

        # 6. 이미지 로깅 (첫 배치만)
        if batch_idx == 0: 
            self.log_images(x[0:1], y[0:1], pred[0:1])

    def log_images(self, clean, noisy, denoised, key="val_samples"):
        """
        WandB에 이미지를 로깅하는 내부 헬퍼 메서드
        """
        # 로거가 없으면 조기 종료
        if self.logger is None:
            return

        # 1. 텐서 -> Numpy 변환 (CPU 이동 포함)
        def to_np(t):
            return np.clip(t[0].detach().cpu().permute(1, 2, 0).numpy(), 0, 1)

        clean_img = to_np(clean)
        noisy_img = to_np(noisy)
        denoised_img = to_np(denoised)

        # 2. 맵 계산 (Error map, Noise map)
        noise_map = np.abs(noisy_img - clean_img)
        noise_map = (noise_map - noise_map.min()) / (noise_map.max() - noise_map.min() + 1e-8)

        residual_map = np.abs(clean_img - denoised_img)
        # 잘 보이게 Contrast 3배 강조 (선택 사항)
        residual_map = np.clip(residual_map * 3, 0, 1) 

        # 3. Plot 생성
        fig, axes = plt.subplots(1, 5, figsize=(20, 5))
        titles = ["GT", "Noisy", "Noise Pattern", "Result", "Error Map"]
        images = [clean_img, noisy_img, noise_map, denoised_img, residual_map]
        cmaps = [None, None, 'gray', None, 'inferno']

        for ax, img, title, cmap in zip(axes, images, titles, cmaps):
            ax.imshow(img, cmap=cmap)
            ax.set_title(title, fontsize=12)
            ax.axis('off')
        
        plt.tight_layout()

        # 4. WandB 로깅
        try:
            # WandbLogger인지 확인하고 로깅
            if hasattr(self.logger, 'experiment'):
                self.logger.experiment.log({
                    f"{key}/epoch_{self.current_epoch}": [wandb.Image(fig, caption=f"PSNR: {-10*np.log10(((clean_img-denoised_img)**2).mean()):.2f}dB")]
                })
        except Exception as e:
            print(f"Logging failed: {e}")
        finally:
            plt.close(fig) # 메모리 정리

def build_run_name(args):
    # 너무 길어지는 거 방지하면서, 실험 구분에 필요한 것만 핵심적으로 넣음
    # 예: dncnn_gaussian_nl0.10_a0.20_img256_bs8_ep30_mc5
    return (
        f"{args.model}_"
        f"a{args.alpha:.2f}_"
        f"img{args.img_size}_"
        f"stride{args.pd_stride}_"
        f"bs{args.batch_size}_"
        f"ep{args.epochs}_"
        f"mc{args.mc_samples}_"
        f"{args.version}"
    )

def main():
    p = argparse.ArgumentParser()

    # data
    p.add_argument("--div2k_root", type=str, required=True)
    p.add_argument("--img_size", type=int, default=256)
    p.add_argument("--batch_size", type=int, default=8)
    p.add_argument("--num_workers", type=int, default=2)

    # GR2R
    p.add_argument("--distribution", type=str, default="gaussian", choices=["gaussian", "poisson", "gamma", "correlated_gaussian",  "correlated_poisson"])
    p.add_argument("--noise_level", type=float, default=0.1)
    p.add_argument("--alpha", type=float, default=0.2)
    p.add_argument("--mc_samples", type=int, default=5)
    p.add_argument("--pd_stride", type=int, default=5)

    # model
    p.add_argument("--model", type=str, default="autoencoder", choices=["autoencoder", "dncnn", "drunet", "unet"])

    # DRUNet sigma control (kept generic; only used when model=drunet)
    p.add_argument("--sigma_mode", type=str, default="noise_level", choices=["noise_level", "fixed"])
    p.add_argument("--sigma_value", type=float, default=0.1)

    # optim/training
    p.add_argument("--epochs", type=int, default=30)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--loss_type", type=str, default="mse")

    # checkpoints/logs
    p.add_argument("--ckpt_dir", type=str, default="./ckpts_gr2r")
    p.add_argument("--init_weights", type=str, default=None,
                   help="Optional: path to weights to initialize model (NOT resume).")
    p.add_argument("--resume", type=str, default=None,
                   help="Optional: lightning checkpoint path to resume training (optimizer/scaler included).")

    p.add_argument("--wandb_project", type=str, default="gr2r-denoising")
    p.add_argument("--wandb_entity", type=str, default=None)
    p.add_argument("--wandb_name", type=str, default=None)
    p.add_argument("--version", type=str, default=None)

    args = p.parse_args()

    root = Path(args.div2k_root)
    train_dir = root / "DIV2K_train_HR"
    val_dir = root / "DIV2K_valid_HR"

    # train_dir = Path("/workspace02/hyemin/nas/datasets/prep/SIDD_s512_o128")
    # val_dir = Path("/workspace02/hyemin/nas/datasets/SIDD")
    
    assert train_dir.exists(), f"Missing: {train_dir}"
    assert val_dir.exists(), f"Missing: {val_dir}"

    train_tf, val_tf = build_transforms(args.img_size)

    train_ds = DIV2KPairs(train_dir, train_tf, args.distribution, args.noise_level)
    val_ds = DIV2KPairs(val_dir, val_tf, args.distribution, args.noise_level)

    # train_ds = SIDDTrainDataset(
    #     root_dir=train_dir,
    #     crop_size=args.img_size
    # )
    # val_ds = SIDDValidationDataset(
    #     noisy_file_path=val_dir / "ValidationNoisyBlocksSrgb.mat",
    #     gt_file_path=val_dir / "ValidationGtBlocksSrgb.mat"
    # )

    train_loader = DataLoader(
        train_ds, batch_size=args.batch_size, shuffle=True,
        num_workers=args.num_workers, pin_memory=True
    )
    val_loader = DataLoader(
        val_ds, batch_size=1, shuffle=False,
        num_workers=args.num_workers, pin_memory=True
    )

    lit_model = PD_GR2R(
        model_name=args.model,
        distribution=args.distribution,
        noise_level=args.noise_level,
        stride = args.pd_stride,
        alpha=args.alpha,
        lr=args.lr,
        loss_type= args.loss_type,
        max_epochs=args.epochs,
        mc_samples=args.mc_samples,
        sigma_mode=args.sigma_mode,
        sigma_value=args.sigma_value,
    )

    # initialize weights (optional) BEFORE training
    if args.init_weights is not None:
        print(f"[init_weights] loading from: {args.init_weights}")
        load_init_weights(lit_model.model, args.init_weights, strict=False)  # strict=False safer for your first try

    ckpt_dir = Path(args.ckpt_dir)
    ckpt_dir.mkdir(parents=True, exist_ok=True)

    callbacks = [
        ModelCheckpoint(
            dirpath=str(ckpt_dir),
            filename="best",
            monitor="val_psnr",
            mode="max",
            save_top_k=1,
        )
    ]

    if args.wandb_name is None or str(args.wandb_name).strip() == "":
        args.wandb_name = build_run_name(args)
        
    logger = WandbLogger(
        project=args.wandb_project,
        entity=args.wandb_entity,
        name=args.wandb_name,
        save_dir=str(ckpt_dir),   # 로컬에도 wandb 관련 파일 저장
        log_model=False,          # 필요하면 True
    )

    trainer = L.Trainer(
        # accumulate_grad_batches=2,
        max_epochs=args.epochs,
        accelerator="gpu" if torch.cuda.is_available() else "cpu",
        devices=1,
        gradient_clip_val=1.0,       # 기울기(Gradient)의 최대 허용 크기
        gradient_clip_algorithm="norm", # 'norm'은 벡터의 전체 길이를 기준으로 자름 (권장)
        # precision="16-mixed" if torch.cuda.is_available() else "32-true",
        callbacks=callbacks,
        log_every_n_steps=20,
        enable_progress_bar=True,
        logger=logger,
    )

    trainer.fit(lit_model, train_loader, val_loader, ckpt_path=args.resume)


if __name__ == "__main__":
    main()
