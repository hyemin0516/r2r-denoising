from __future__ import annotations
import argparse
from pathlib import Path
from typing import Optional, Dict, Any

import numpy as np
import matplotlib.pyplot as plt
import wandb

import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader

import lightning as L
from lightning.pytorch.callbacks import ModelCheckpoint
from lightning.pytorch.loggers import WandbLogger

from torchmetrics.image import PeakSignalNoiseRatio, StructuralSimilarityIndexMeasure

from .datasets.div2k import DIV2KPairs
from .models.autoencoder import Autoencoder
from .models.dncnn import DnCNN
from .models.drunet import DRUNet
from .utils.noise import get_noise_fns
from .utils.transform import build_transforms
from .utils.pixel_downsampling import pixel_unshuffle, pixel_shuffle


def load_init_weights(model: torch.nn.Module, ckpt_path: str, strict: bool = True) -> None:
    """
    Load initial weights ONLY (no optimizer/scheduler/scaler).
    Supports:
      - plain state_dict (.pth/.pt)  (keys match model)
      - lightning checkpoint (.ckpt) (state_dict keys like "model.xxx" or "xxx")
    """
    ckpt = torch.load(ckpt_path, map_location="cpu")

    # case A) lightning ckpt
    if isinstance(ckpt, dict) and "state_dict" in ckpt:
        sd = ckpt["state_dict"]
    # case B) common wrappers
    elif isinstance(ckpt, dict) and "model" in ckpt:
        sd = ckpt["model"]
    else:
        sd = ckpt

    # strip common prefixes
    new_sd = {}
    for k, v in sd.items():
        if k.startswith("model."):
            new_sd[k[len("model."):]] = v
        elif k.startswith("module."):
            new_sd[k[len("module."):]] = v
        else:
            new_sd[k] = v

    missing, unexpected = model.load_state_dict(new_sd, strict=strict)
    if len(missing) or len(unexpected):
        print(f"[init_weights] missing={len(missing)}, unexpected={len(unexpected)}")
        if len(missing):
            print("  missing keys (first 20):", missing[:20])
        if len(unexpected):
            print("  unexpected keys (first 20):", unexpected[:20])


def build_model(model_name: str) -> torch.nn.Module:
    m = model_name.lower()
    if m == "autoencoder":
        return Autoencoder(in_ch=3, base=32)
    if m == "dncnn":
        # DnCNN: input/output same channels
        return DnCNN(in_channels=3, out_channels=3, depth=20, nf=64, bias=True)
    if m == "drunet":
        # DRUNet expects sigma channel inside; we pass sigma via forward(x, sigma=...)
        return DRUNet(in_channels=3, out_channels=3)
    raise ValueError(f"Unknown model: {model_name} (choose from autoencoder|dncnn|drunet)")

def estimate_sigma_mad(img_sub):
    """
    Robust Noise Level Estimation using MAD (Median Absolute Deviation)
    입력: PD가 적용된 Sub-image (B*s^2, C, H/s, W/s) - 노이즈가 독립적이라고 가정
    출력: 추정된 Sigma 값 (B,)
    """
    # 1. 고주파 성분 추출 (High-pass filtering)
    # 이미지의 텍스처를 배제하고 노이즈만 남기기 위해 인접 픽셀과 뺄셈을 합니다.
    # (B, C, H, W-1)
    diff = img_sub[..., 1:] - img_sub[..., :-1] 
    
    # 2. MAD 계산
    # 공식: sigma = median(|x - median(x)|) / 0.6745
    # 정규분포(Gaussian) 가정 하에 표준편차의 근사값을 구합니다.
    
    # 배치를 제외한 나머지 차원으로 평탄화 (B, -1)
    diff_flat = diff.view(diff.size(0), -1)
    
    # 중앙값(Median) 계산 (각 배치별로)
    median_val = torch.median(diff_flat, dim=1, keepdim=True).values
    
    # 편차의 절댓값의 중앙값
    mad = torch.median(torch.abs(diff_flat - median_val), dim=1).values
    
    # 정규분포 상수(0.6745)로 보정하여 Sigma 도출
    sigma_est = mad / 0.6745
    
    return sigma_est

class CharbonnierLoss(torch.nn.Module):
    def __init__(self, eps=1e-3):
        super(CharbonnierLoss, self).__init__()
        self.eps = eps

    def forward(self, x, y):
        diff = x - y
        # L1과 비슷하지만 미분 가능 (sqrt(x^2 + eps^2))
        loss = torch.sqrt(diff * diff + self.eps * self.eps)
        return torch.mean(loss)

def extract_grid_pattern(image, stride=2):
    """
    이미지에서 격자 패턴(Artifact)만 추출하여 반환
    """
    b, c, h, w = image.shape
    unshuffled = image.view(b, c, h // stride, stride, w // stride, stride)
    local_mean = unshuffled.mean(dim=(3, 5), keepdim=True)
    deviation = unshuffled - local_mean
    
    # 편차에서 텍스처 제거하고 격자만 남김 (Low Pass Filter)
    dev_flat = deviation.permute(0, 1, 3, 5, 2, 4).reshape(-1, 1, h // stride, w // stride)
    n_grid_flat = F.avg_pool2d(dev_flat, kernel_size=3, stride=1, padding=1)
    
    # 격자 패턴 복원
    n_grid = n_grid_flat.view(b, c, stride, stride, h // stride, w // stride).permute(0, 1, 4, 2, 5, 3)
    n_grid_full = n_grid.reshape(b, c, h, w)
    
    return n_grid_full


class PD_GR2R(L.LightningModule):
    def __init__(
        self,
        model_name: str,
        distribution: str,
        noise_level: float,
        stride: int,
        alpha: float,
        lr: float,
        loss_type: str,
        max_epochs: int,
        mc_samples: int,
        sigma_mode: str = "noise_level",   # how to set sigma for DRUNet: noise_level or fixed
        sigma_value: float = 0.1,          # used when sigma_mode="fixed"
    ):
        super().__init__()
        self.save_hyperparameters()

        self.model = build_model(model_name=model_name)

        # GR2R corruptor depends on distribution
        _, self.corruptor = get_noise_fns(distribution)
        self.stride = stride

        self.psnr = PeakSignalNoiseRatio(data_range=1.0)
        self.ssim = StructuralSimilarityIndexMeasure(data_range=1.0)

        self.cbl_loss = CharbonnierLoss()

    def configure_optimizers(self):
        optimizer = torch.optim.AdamW(self.parameters(), lr=self.hparams.lr)
        step_size = int(self.hparams.max_epochs * 0.8) + 1

        # scheduler = torch.optim.lr_scheduler.StepLR(
        #     optimizer, 
        #     step_size=step_size, 
        #     gamma=0.1 # LR을 1/10로 줄임 (일반적인 세팅)
        # )

        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer,
            T_max=self.hparams.max_epochs,  # 예: 100
            eta_min=1e-6  # 최소 LR (0이 되지 않게 안전장치)
        )
        
        return [optimizer], [scheduler]
    
    def forward(self, x: torch.Tensor, sigma_map=None):
        # 1. DRUNet이 아니면 Sigma 필요 없음
        if self.hparams.model_name.lower() != "drunet":
            return self.model(x)
    
        # 2. Sigma 값 결정 (우선순위: sigma_map > hparams)
        if sigma_map is not None:
            sigma = sigma_map
        else:
            if self.hparams.sigma_mode == "fixed":
                sigma_val = float(self.hparams.sigma_value)
            else:
                sigma_val = float(self.hparams.noise_level)
            # x의 배치 크기에 맞춰서 생성
            sigma = torch.full((x.size(0),), sigma_val, device=x.device, dtype=x.dtype)

        # 3. [핵심 수정] 차원 불일치 자동 보정 로직
        # PD(Pixel-Downsampling)를 거친 이미지 x는 배치 크기가 늘어남 (B -> B*s^2)
        # 하지만 입력된 sigma는 원본 배치 크기(B)일 수 있음. 이때 늘려줘야 함.
        if isinstance(sigma, torch.Tensor) and sigma.ndim == 1:
            if x.size(0) != sigma.size(0):
                # 배수가 맞다면 (예: 이미지 4장, 시그마 1개 -> 4배 복사)
                if x.size(0) > sigma.size(0) and x.size(0) % sigma.size(0) == 0:
                    repeat_factor = x.size(0) // sigma.size(0)
                    sigma = sigma.repeat_interleave(repeat_factor)
        
        return self.model(x, sigma=sigma)
        # return self.model(x)

    def r2r_loss(self, 
                 pred: torch.Tensor, 
                 target: torch.Tensor) -> torch.Tensor:
        if self.hparams.loss_type == "mse":
            loss = torch.nn.functional.mse_loss(pred, target)

        elif self.hparams.loss_type == "cbl":
            loss = self.cbl_loss(pred, target)

        elif self.hparams.loss_type == "nll":
            mu, log_var = torch.chunk(pred, 2, dim=1)
            log_var = torch.clamp(log_var, min=-10, max=10)
            var = torch.exp(log_var)

            loss = torch.nn.functional.gaussian_nll_loss(mu, target, var, reduction='mean')

        return loss

    def training_step(self, batch, batch_idx):
        y = batch["y"]

        alpha = float(self.hparams.alpha)
        # nl = float(self.hparams.noise_level)

        with torch.no_grad():
            y_sub_temp = pixel_unshuffle(y, self.stride)
            
            sigma_est = estimate_sigma_mad(y_sub_temp)
            sigma_est = sigma_est.clamp(min=0.01, max=1.0)
            b_size = y.size(0)
            sigma_for_recorruption = sigma_est.view(b_size, -1).mean(dim=1)

        y1 = self.corruptor(y, alpha, noise_level=sigma_for_recorruption.view(-1, 1, 1, 1))

        y_sub = pixel_unshuffle(y, self.stride)
        y1_sub = pixel_unshuffle(y1, self.stride)
        
        y2_sub = (1.0 / alpha) * (y_sub - y1_sub * (1.0 - alpha))
        y2 = pixel_shuffle(y2_sub, self.stride)
        
        pred_sub = self.forward(y1_sub.clamp(0,1), sigma_for_recorruption)
        pred1_full = pixel_shuffle(pred_sub, self.stride)

        loss1 = self.r2r_loss(pred1_full, y2)

        with torch.no_grad():
            input_for_step2 = pred1_full.detach()
            raw_grid = extract_grid_pattern(input_for_step2, self.stride)

            threshold = 0.02
            grid_filtered = torch.sign(raw_grid) * torch.relu(torch.abs(raw_grid) - threshold)
            grid_filtered = grid_filtered*1.5

        input_step2_recorrupted = input_for_step2 + grid_filtered
        target_step2_clean = input_for_step2 - grid_filtered

        input_sub = pixel_unshuffle(input_step2_recorrupted, self.stride)
        target_sub = pixel_unshuffle(target_step2_clean, self.stride)

        sigma_step2 = torch.full_like(sigma_for_recorruption, 1e-2)
        
        pred2_sub = self.forward(input_sub, sigma_step2)

        loss2 = F.mse_loss(pred2_sub, target_sub) * 30.0

        loss = loss1 + loss2
        
        self.log("noise_loss", loss1, prog_bar=True, on_step=True, on_epoch=True)
        self.log("artifact_loss", loss2, prog_bar=True, on_step=True, on_epoch=True)
        self.log("train_loss", loss, prog_bar=True, on_step=True, on_epoch=True)
        return loss

    @torch.no_grad()
    def validation_step(self, batch, batch_idx):
        x = batch["x"]
        y = batch["y"]

        J = int(self.hparams.mc_samples)
        pred_accum = torch.zeros_like(y) # 누적할 텐서 초기화

        for _ in range(J):
            # ---------------------------------------------------
            # 1. Sigma 추정 (Blind Noise Level Estimation)
            # ---------------------------------------------------
            # PD로 쪼개서 독립성 확보 후 Sigma 추정
            y_sub_temp = pixel_unshuffle(y, 2)
            sigma_est = estimate_sigma_mad(y_sub_temp)
            
            # 너무 작거나 큰 값 방지 (안전장치)
            sigma_est = sigma_est.clamp(min=0.001, max=1.0) 

            # (B,) 형태: 모델 forward용
            b_size = y.size(0)
            sigma_val = sigma_est.view(b_size, -1).mean(dim=1)
            
            # (B, 1, 1, 1) 형태: Corruptor 브로드캐스팅용 (에러 방지 핵심!)
            sigma_map = sigma_val.view(b_size, 1, 1, 1)

            # ---------------------------------------------------
            # 2. Recorruption (Blind Setting)
            # ---------------------------------------------------
            # 'hparams.noise_level'(고정값) 대신 '추정된 sigma_map' 사용
            alpha = float(self.hparams.alpha)
            y1 = self.corruptor(y, alpha, noise_level=sigma_map)

            # 모델 입력을 위해 PD 수행
            y1_sub = pixel_unshuffle(y1, 2)

            # ---------------------------------------------------
            # 3. Model Forward (MSE / NLL 호환 로직)
            # ---------------------------------------------------
            # 모델 실행
            output_sub = self.forward(y1_sub.clamp(0, 1), sigma_val)

            # [핵심] NLL Loss 사용 시 채널이 6개(Mean+Var)이므로 앞 3개(Mean)만 잘라냄
            if output_sub.shape[1] == 6:
                denoised_sub = output_sub.chunk(2, dim=1)[0]
            else:
                denoised_sub = output_sub # MSE 모델이면 그대로 사용

            # ---------------------------------------------------
            # 4. 복원 및 누적
            # ---------------------------------------------------
            # 다시 합쳐서(Pixel Shuffle) 누적
            pred_accum += pixel_shuffle(denoised_sub, 2)

        pred = pred_accum / float(J)
        pred = torch.clamp(pred, 0.0, 1.0)
        
        self.log("val_psnr", self.psnr(pred, x), prog_bar=True, on_step=False, on_epoch=True)
        self.log("val_ssim", self.ssim(pred, x), prog_bar=False, on_step=False, on_epoch=True)

        if batch_idx == 0:
            # 깔끔하게 내부 메서드 호출!
            self.log_images(x[0:1], y[0:1], pred[0:1])

    def log_images(self, clean, noisy, denoised, key="val_samples"):
        """
        WandB에 이미지를 로깅하는 내부 헬퍼 메서드
        """
        # 로거가 없으면 조기 종료
        if self.logger is None:
            return

        # 1. 텐서 -> Numpy 변환 (CPU 이동 포함)
        def to_np(t):
            return np.clip(t[0].detach().cpu().permute(1, 2, 0).numpy(), 0, 1)

        clean_img = to_np(clean)
        noisy_img = to_np(noisy)
        denoised_img = to_np(denoised)

        # 2. 맵 계산 (Error map, Noise map)
        noise_map = np.abs(noisy_img - clean_img)
        noise_map = (noise_map - noise_map.min()) / (noise_map.max() - noise_map.min() + 1e-8)

        residual_map = np.abs(clean_img - denoised_img)
        # 잘 보이게 Contrast 3배 강조 (선택 사항)
        residual_map = np.clip(residual_map * 3, 0, 1) 

        # 3. Plot 생성
        fig, axes = plt.subplots(1, 5, figsize=(20, 5))
        titles = ["GT", "Noisy", "Noise Pattern", "Result", "Error Map"]
        images = [clean_img, noisy_img, noise_map, denoised_img, residual_map]
        cmaps = [None, None, 'gray', None, 'inferno']

        for ax, img, title, cmap in zip(axes, images, titles, cmaps):
            ax.imshow(img, cmap=cmap)
            ax.set_title(title, fontsize=12)
            ax.axis('off')
        
        plt.tight_layout()

        # 4. WandB 로깅
        try:
            # WandbLogger인지 확인하고 로깅
            if hasattr(self.logger, 'experiment'):
                self.logger.experiment.log({
                    f"{key}/epoch_{self.current_epoch}": [wandb.Image(fig, caption=f"PSNR: {-10*np.log10(((clean_img-denoised_img)**2).mean()):.2f}dB")]
                })
        except Exception as e:
            print(f"Logging failed: {e}")
        finally:
            plt.close(fig) # 메모리 정리

def build_run_name(args):
    # 너무 길어지는 거 방지하면서, 실험 구분에 필요한 것만 핵심적으로 넣음
    # 예: dncnn_gaussian_nl0.10_a0.20_img256_bs8_ep30_mc5
    return (
        f"{args.model}_"
        f"{args.distribution}_"
        f"nl{args.noise_level:.2f}_"
        f"a{args.alpha:.2f}_"
        f"img{args.img_size}_"
        f"bs{args.batch_size}_"
        f"ep{args.epochs}_"
        f"mc{args.mc_samples}_"
        f"{args.version}"
    )

def main():
    p = argparse.ArgumentParser()

    # data
    p.add_argument("--div2k_root", type=str, required=True)
    p.add_argument("--img_size", type=int, default=256)
    p.add_argument("--batch_size", type=int, default=8)
    p.add_argument("--num_workers", type=int, default=2)

    # GR2R
    p.add_argument("--distribution", type=str, default="gaussian", choices=["gaussian", "poisson", "gamma", "correlated_gaussian",  "correlated_poisson"])
    p.add_argument("--noise_level", type=float, default=0.1)
    p.add_argument("--alpha", type=float, default=0.2)
    p.add_argument("--mc_samples", type=int, default=5)

    # model
    p.add_argument("--model", type=str, default="autoencoder", choices=["autoencoder", "dncnn", "drunet"])

    # DRUNet sigma control (kept generic; only used when model=drunet)
    p.add_argument("--sigma_mode", type=str, default="noise_level", choices=["noise_level", "fixed"])
    p.add_argument("--sigma_value", type=float, default=0.1)

    # optim/training
    p.add_argument("--epochs", type=int, default=30)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--loss_type", type=str, default="mse")

    # checkpoints/logs
    p.add_argument("--ckpt_dir", type=str, default="./ckpts_gr2r")
    p.add_argument("--init_weights", type=str, default=None,
                   help="Optional: path to weights to initialize model (NOT resume).")
    p.add_argument("--resume", type=str, default=None,
                   help="Optional: lightning checkpoint path to resume training (optimizer/scaler included).")

    p.add_argument("--wandb_project", type=str, default="gr2r-denoising")
    p.add_argument("--wandb_entity", type=str, default=None)
    p.add_argument("--wandb_name", type=str, default=None)
    p.add_argument("--version", type=str, default=None)

    args = p.parse_args()

    root = Path(args.div2k_root)
    train_dir = root / "DIV2K_train_HR"
    val_dir = root / "DIV2K_valid_HR"
    assert train_dir.exists(), f"Missing: {train_dir}"
    assert val_dir.exists(), f"Missing: {val_dir}"

    train_tf, val_tf = build_transforms(args.img_size)

    train_ds = DIV2KPairs(train_dir, train_tf, args.distribution, args.noise_level)
    val_ds = DIV2KPairs(val_dir, val_tf, args.distribution, args.noise_level)

    train_loader = DataLoader(
        train_ds, batch_size=args.batch_size, shuffle=True,
        num_workers=args.num_workers, pin_memory=True
    )
    val_loader = DataLoader(
        val_ds, batch_size=1, shuffle=False,
        num_workers=args.num_workers, pin_memory=True
    )

    lit_model = PD_GR2R(
        model_name=args.model,
        distribution=args.distribution,
        noise_level=args.noise_level,
        stride = 4,
        alpha=args.alpha,
        lr=args.lr,
        loss_type= args.loss_type,
        max_epochs=args.epochs,
        mc_samples=args.mc_samples,
        sigma_mode=args.sigma_mode,
        sigma_value=args.sigma_value,
    )

    # initialize weights (optional) BEFORE training
    if args.init_weights is not None:
        print(f"[init_weights] loading from: {args.init_weights}")
        load_init_weights(lit_model.model, args.init_weights, strict=False)  # strict=False safer for your first try

    ckpt_dir = Path(args.ckpt_dir)
    ckpt_dir.mkdir(parents=True, exist_ok=True)

    callbacks = [
        ModelCheckpoint(
            dirpath=str(ckpt_dir),
            filename="best",
            monitor="val_psnr",
            mode="max",
            save_top_k=1,
        )
    ]

    if args.wandb_name is None or str(args.wandb_name).strip() == "":
        args.wandb_name = build_run_name(args)
        
    logger = WandbLogger(
        project=args.wandb_project,
        entity=args.wandb_entity,
        name=args.wandb_name,
        save_dir=str(ckpt_dir),   # 로컬에도 wandb 관련 파일 저장
        log_model=False,          # 필요하면 True
    )

    trainer = L.Trainer(
        # accumulate_grad_batches=3,
        max_epochs=args.epochs,
        accelerator="gpu" if torch.cuda.is_available() else "cpu",
        devices=1,
        gradient_clip_val=1.0,       # 기울기(Gradient)의 최대 허용 크기
        gradient_clip_algorithm="norm", # 'norm'은 벡터의 전체 길이를 기준으로 자름 (권장)
        # precision="16-mixed" if torch.cuda.is_available() else "32-true",
        callbacks=callbacks,
        log_every_n_steps=20,
        enable_progress_bar=True,
        logger=logger,
    )

    trainer.fit(lit_model, train_loader, val_loader, ckpt_path=args.resume)


if __name__ == "__main__":
    main()
