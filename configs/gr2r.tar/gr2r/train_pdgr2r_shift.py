from __future__ import annotations
import argparse
from pathlib import Path
from typing import Optional, Dict, Any
from omegaconf import DictConfig
from omegaconf import OmegaConf


import numpy as np
import matplotlib.pyplot as plt
import wandb

import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from pytorch_msssim import ms_ssim

import lightning as L
from lightning.pytorch.callbacks import ModelCheckpoint
from lightning.pytorch.loggers import WandbLogger

from torchmetrics.image import PeakSignalNoiseRatio, StructuralSimilarityIndexMeasure

from .datasets.div2k import DIV2KPairs
from .datasets.sidd import SIDDTrainDataset, SIDDValidationDataset
from .models.autoencoder import Autoencoder
from .models.dncnn import DnCNN
from .models.drunet import DRUNet
from .models.unet import UNet
from .utils.noise import get_noise_fns
from .utils.transform import build_transforms
from .utils.pixel_downsampling import pixel_unshuffle, pixel_shuffle
from .utils.estimate_sigma import estimate_sigma_mad, estimate_sigma_mad_map, estimate_smart_sigma
from .utils.grid_injection import get_grid_noise_map


def load_init_weights(model: torch.nn.Module, ckpt_path: str, strict: bool = True) -> None:
    """
    Load initial weights ONLY (no optimizer/scheduler/scaler).
    Supports:
      - plain state_dict (.pth/.pt)  (keys match model)
      - lightning checkpoint (.ckpt) (state_dict keys like "model.xxx" or "xxx")
    """
    ckpt = torch.load(ckpt_path, map_location="cpu")

    # case A) lightning ckpt
    if isinstance(ckpt, dict) and "state_dict" in ckpt:
        sd = ckpt["state_dict"]
    # case B) common wrappers
    elif isinstance(ckpt, dict) and "model" in ckpt:
        sd = ckpt["model"]
    else:
        sd = ckpt

    # strip common prefixes
    new_sd = {}
    for k, v in sd.items():
        if k.startswith("model."):
            new_sd[k[len("model."):]] = v
        elif k.startswith("module."):
            new_sd[k[len("module."):]] = v
        else:
            new_sd[k] = v

    missing, unexpected = model.load_state_dict(new_sd, strict=strict)
    if len(missing) or len(unexpected):
        print(f"[init_weights] missing={len(missing)}, unexpected={len(unexpected)}")
        if len(missing):
            print("  missing keys (first 20):", missing[:20])
        if len(unexpected):
            print("  unexpected keys (first 20):", unexpected[:20])


def build_model(model_name: str) -> torch.nn.Module:
    m = model_name.lower()
    if m == "autoencoder":
        return Autoencoder(in_ch=3, base=32)
    if m == "dncnn":
        # DnCNN: input/output same channels
        return DnCNN(in_channels=3, out_channels=3, depth=20, nf=64, bias=True)
    if m == "drunet":
        # DRUNet expects sigma channel inside; we pass sigma via forward(x, sigma=...)
        return DRUNet(in_channels=3, out_channels=3)
    if m == "unet":
        return UNet(in_channels=3, out_channels=3)
    raise ValueError(f"Unknown model: {model_name} (choose from autoencoder|dncnn|drunet)")

class CharbonnierLoss(torch.nn.Module):
    def __init__(self, eps=1e-3):
        super(CharbonnierLoss, self).__init__()
        self.eps = eps

    def forward(self, x, y, weight_map=None):
        diff = x - y
        # L1과 비슷하지만 미분 가능 (sqrt(x^2 + eps^2))
        loss = torch.sqrt(diff * diff + self.eps * self.eps)
        if weight_map is not None:
            loss = loss * weight_map
            
        return torch.mean(loss)

# def extract_grid_pattern(image, stride=2):
#     """
#     이미지에서 격자 패턴(Artifact)만 추출하여 반환
#     """
#     b, c, h, w = image.shape
#     unshuffled = image.view(b, c, h // stride, stride, w // stride, stride)
#     local_mean = unshuffled.mean(dim=(3, 5), keepdim=True)
#     deviation = unshuffled - local_mean
    
#     # 편차에서 텍스처 제거하고 격자만 남김 (Low Pass Filter)
#     dev_flat = deviation.permute(0, 1, 3, 5, 2, 4).reshape(-1, 1, h // stride, w // stride)
#     n_grid_flat = F.avg_pool2d(dev_flat, kernel_size=3, stride=1, padding=1)
    
#     # 격자 패턴 복원
#     n_grid = n_grid_flat.view(b, c, stride, stride, h // stride, w // stride).permute(0, 1, 4, 2, 5, 3)
#     n_grid_full = n_grid.reshape(b, c, h, w)
    
#     return n_grid_full

def extract_grid_pattern(image, stride=4):
    """
    이미지에서 텍스트/배경 찌꺼기를 완벽히 제거하고 
    순수한 주기적 격자 패턴(Periodic Grid Artifact)만 추출하여 반환합니다.
    """
    b, c, h, w = image.shape
    
    # 1. 이미지를 stride x stride 크기의 블록들로 분해
    # shape: (B, C, H // stride, stride, W // stride, stride)
    unshuffled = image.view(b, c, h // stride, stride, w // stride, stride)
    
    # 2. 블록 내 로컬 평균(DC 성분) 제거
    # 픽셀 셔플로 인한 아티팩트는 주로 픽셀 간의 고주파 편차에서 발생하므로 DC를 뺍니다.
    local_mean = unshuffled.mean(dim=(3, 5), keepdim=True)
    deviation = unshuffled - local_mean
    
    # 3. [핵심] 주기성 격자 필터링 (Periodic Averaging)
    # 기존의 3x3 avg_pool(국소 필터) 대신, 전체 공간 차원(H//stride, W//stride)에 대해 평균을 냅니다.
    # 불규칙한 텍스트 엣지는 0으로 완벽히 상쇄되고, 순수 격자 커널만 남습니다.
    # shape: (B, C, 1, stride, 1, stride)
    pure_grid_kernel = deviation.mean(dim=(2, 4), keepdim=True)
    
    # 4. 추출된 순수 격자 커널을 원본 이미지 크기로 복사(Tiling)
    # shape: (B, C, H // stride, stride, W // stride, stride)
    pure_grid_tiled = pure_grid_kernel.expand(-1, -1, h // stride, -1, w // stride, -1)
    
    # 5. 원래의 이미지 차원으로 복구
    pure_grid_full = pure_grid_tiled.reshape(b, c, h, w)
    
    return pure_grid_full

def extract_grid_pattern_v3(pred, y, stride=4):
    """
    원본 이미지(y)를 참조(Reference)로 사용하여 글씨/배경 구조를 완벽히 상쇄한 후,
    순수한 주기적 격자 패턴만 추출합니다.
    """
    b, c, h, w = pred.shape
    
    # 1. [핵심] 구조적 정보 상쇄 (Text Cancel-out)
    # 글씨 구조가 사라지고 오직 '격자'와 '노이즈'만 남은 순수 잔차 맵이 됩니다.
    residual = pred - y
    
    # 2. stride x stride 블록으로 분해
    unshuffled = residual.view(b, c, h // stride, stride, w // stride, stride)
    
    # 3. 주기성 격자 필터링 (Periodic Averaging)
    # 랜덤 노이즈는 평균을 통해 0으로 수렴하여 사라지고, 
    # 주기성을 가진 격자(Grid) 패턴만 완벽하게 살아남아 응축됩니다.
    pure_grid_kernel = unshuffled.mean(dim=(2, 4), keepdim=True)
    
    # 4. 추출된 순수 격자 커널을 원본 크기로 복사(Tiling)
    pure_grid_tiled = pure_grid_kernel.expand(-1, -1, h // stride, -1, w // stride, -1)
    
    # 5. 원래 이미지 차원으로 복구
    pure_grid_full = pure_grid_tiled.reshape(b, c, h, w)
    
    return pure_grid_full


class PD_GR2R(L.LightningModule):
    def __init__(self, config: DictConfig):
        super().__init__()
        self.save_hyperparameters()
        self.cfg = config

        self.model = build_model(model_name=self.cfg.model.name)

        # GR2R corruptor depends on distribution
        _, self.corruptor = get_noise_fns(self.cfg.r2r.noise_dist)

        self.psnr = PeakSignalNoiseRatio(data_range=1.0)
        self.ssim = StructuralSimilarityIndexMeasure(data_range=1.0)

        self.cbl_loss = CharbonnierLoss()

    def configure_optimizers(self):
        optimizer = torch.optim.AdamW(self.parameters(), lr=self.cfg.train.lr)
        step_size = int(self.cfg.train.max_epochs * 0.8) + 1

        # scheduler = torch.optim.lr_scheduler.StepLR(
        #     optimizer, 
        #     step_size=step_size, 
        #     gamma=0.1 # LR을 1/10로 줄임 (일반적인 세팅)
        # )

        # scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        #     optimizer,
        #     # T_max=self.hparams.max_epochs,  # 예: 100
        #     T_max=self.trainer.max_steps,
        #     eta_min=1e-6  # 최소 LR (0이 되지 않게 안전장치)
        # )

        scheduler = torch.optim.lr_scheduler.MultiStepLR(
                optimizer,
                # milestones=[4500, 7500],  
                milestones=[3000, 6000],
                gamma=0.5                        
        )       
        
        # return [optimizer], [scheduler]
        return {
            "optimizer": optimizer,
            "lr_scheduler": {
                "scheduler": scheduler,
                "interval": "step",  # ★ 매우 중요: 'epoch'이 아니라 'step'마다 갱신!
                "frequency": 1,
                # "monitor": "val_psnr", # (선택사항) ReduceLROnPlateau 쓸 때만 필요
                "strict": True,
            }
        }
    
    def forward(self, x: torch.Tensor, sigma_map=None):
        # ==========================================================
        # [수정] Zero-Padding Artifact 방지 (Ghosting 해결 핵심)
        # ==========================================================
        # 모델(DnCNN 등)이 3x3 Conv를 쓸 때 테두리에 0을 채우는데,
        # PD로 쪼개진 이미지에서는 이 테두리가 나중에 합쳐질 때 
        # 이미지 정중앙에 '검은 격자'나 '위치 어긋남'을 만듭니다.
        # 이를 막기 위해 입력 이미지를 미리 거울처럼 반사(Reflect)해서 넓혀줍니다.
        
        pad_size = 16  # 8픽셀 정도면 충분합니다 (Receptive Field 고려)
        x_pad = F.pad(x, (pad_size, pad_size, pad_size, pad_size), mode='reflect')

        # ----------------------------------------------------------
        # 기존 로직 (Sigma 처리 등)
        # ----------------------------------------------------------
        # 1. DRUNet이 아니면 Sigma 필요 없음
        if self.cfg.model.name.lower() != "drunet":
            out_pad = self.model(x_pad)
        else:
            # 2. Sigma 값 결정
            if sigma_map is not None:
                sigma = sigma_map
            else:
                if self.cfg.r2r.sigma_mode.lower() == "fixed":
                    sigma_val = float(self.cfg.r2r.sigma_value)
                else:
                    sigma_val = float(self.cfg.r2r.noise_level)
                sigma = torch.full((x.size(0),), sigma_val, device=x.device, dtype=x.dtype)

            # 3. 차원 불일치 자동 보정 (x_pad 사이즈 기준)
            if isinstance(sigma, torch.Tensor) and sigma.ndim == 1:
                # x가 PD로 인해 배치가 늘어났는데 sigma가 원본 배치 사이즈라면
                if x_pad.size(0) != sigma.size(0):
                    if x_pad.size(0) > sigma.size(0) and x_pad.size(0) % sigma.size(0) == 0:
                        repeat_factor = x_pad.size(0) // sigma.size(0)
                        sigma = sigma.repeat_interleave(repeat_factor)
            
            out_pad = self.model(x_pad, sigma=sigma)

        # ==========================================================
        # [복구] 아까 붙였던 패딩만큼 다시 잘라내기 (Center Crop)
        # ==========================================================
        out = out_pad[..., pad_size:-pad_size, pad_size:-pad_size]
        
        return out

    def r2r_loss(self, 
                 pred: torch.Tensor, 
                 target: torch.Tensor,
                 weight_map=None) -> torch.Tensor:
        if self.cfg.train.loss_type == "mse":
            loss = torch.nn.functional.mse_loss(pred, target)

        elif self.cfg.train.loss_type == "cbl":
            loss = self.cbl_loss(pred, target, weight_map=weight_map)

        elif self.cfg.train.loss_type == "nll":
            mu, log_var = torch.chunk(pred, 2, dim=1)
            log_var = torch.clamp(log_var, min=-10, max=10)
            var = torch.exp(log_var)

            loss = torch.nn.functional.gaussian_nll_loss(mu, target, var, reduction='mean')

        return loss

    def training_step(self, batch, batch_idx):
        y = batch["y"] 
        alpha = float(self.cfg.r2r.alpha)
        stride = self.cfg.r2r.pd_stride

        with torch.no_grad():
            sigma_map = estimate_smart_sigma(y) * self.cfg.r2r.sigma_value
            y1 = self.corruptor(y, alpha, noise_level=sigma_map)
            y2 = (1.0 / alpha) * (y - y1 * (1.0 - alpha))
            
        # ===========================================================
        # Phase 1. Original R2R Forward (기존과 동일)
        # ===========================================================
        y1_sub = pixel_unshuffle(y1, stride)
        y2_sub = pixel_unshuffle(y2, stride) 

        pred_sub = self.forward(y1_sub.clamp(0, 1))
        
        # 앞서 최적화한 대로 한 쪽 도메인에서 구하고 2배를 곱함
        loss_main = self.r2r_loss(pred_sub, y2_sub) * 2.0

        # ===========================================================
        # Phase 2. Shifted Forward (이동 불변성 강제)
        # ===========================================================
        # 원본 입력(y1)을 대각선(오른쪽 1, 아래 1)으로 1픽셀 이동
        y1_shift = torch.roll(y1, shifts=(1, 1), dims=(2, 3))
        
        # 이동된 입력을 PD 적용 후 모델 통과
        y1_shift_sub = pixel_unshuffle(y1_shift, stride)
        pred_shift_sub = self.forward(y1_shift_sub.clamp(0, 1))

        # ===========================================================
        # Phase 3. Consistency Loss 계산 (격자 파괴 타격점)
        # ===========================================================
        # 구조를 비교하기 위해 Full 도메인으로 복원
        pred_full = pixel_shuffle(pred_sub, stride)
        pred_shift_full = pixel_shuffle(pred_shift_sub, stride)

        # 1. 원본 예측(pred_full)을 y1처럼 똑같이 1픽셀 이동시킴
        pred_full_shifted = torch.roll(pred_full, shifts=(1, 1), dims=(2, 3))

        # 2. Wrap-around 테두리 제외 (핵심 디테일)
        # torch.roll은 끝 픽셀이 반대편으로 넘어가므로 이 부분은 비교에서 제외
        valid_pred_shift_full = pred_shift_full[:, :, 1:, 1:]
        valid_pred_full_shifted = pred_full_shifted[:, :, 1:, 1:]

        # 3. 두 결과물이 완벽히 일치하도록 L1 Loss 강제
        loss_cons = F.l1_loss(valid_pred_shift_full, valid_pred_full_shifted)

        # ===========================================================
        # Phase 4. 최종 Loss 융합
        # ===========================================================
        # consistency 가중치 (0.1 ~ 0.5 사이를 권장하며, 점진적 스케줄링도 좋습니다)
        lambda_cons = 0.5 
        loss = loss_main + (lambda_cons * loss_cons)

        # 로깅
        self.log("loss_main", loss_main, prog_bar=True)
        self.log("loss_cons", loss_cons, prog_bar=True)
        self.log("train_loss", loss, prog_bar=True)
        
        return loss

    @torch.no_grad()
    def validation_step(self, batch, batch_idx):
        x = batch["x"]
        y = batch["y"]

        J = int(self.cfg.r2r.mc_samples)
        pred_accum = torch.zeros_like(y) 

        for _ in range(J):
            # ---------------------------------------------------
            # 1. Sigma 추정
            # ---------------------------------------------------
            y_sub_temp = pixel_unshuffle(y, self.cfg.r2r.pd_stride) # stride 변수 사용 추천
            
            # (B, 1, H, W) 맵 생성
            # sigma_map = estimate_sigma_mad_map(y_sub_temp, 2)*0.5
            # sigma_map = sigma_map.clamp(min=0.001, max=1.0) 
            # sigma_map = torch.full_like(y, 0.05)
            sigma_map = estimate_smart_sigma(y) * self.cfg.r2r.sigma_value
            # real_noise = y - x
            # sigma_map = torch.abs(real_noise)

            # [수정] 모델용 평균값 계산 (Corruptor용 아님!)
            b_size = y.size(0)
            sigma_val = sigma_map.view(b_size, -1).mean(dim=1) # (B,)
            
            # ---------------------------------------------------
            # 2. Recorruption
            # ---------------------------------------------------
            alpha = float(self.cfg.r2r.alpha)
            
            # [핵심 수정] 
            # 평균낸 값(sigma_val)이 아니라, 맵(sigma_map)을 그대로 넣어야 함!
            # 그래야 위치별로 정확한 R2R 검증이 가능함.
            y1 = self.corruptor(y, alpha, noise_level=sigma_map)

            y1_sub = pixel_unshuffle(y1, self.cfg.r2r.pd_stride)

            # ---------------------------------------------------
            # 3. Model Forward
            # ---------------------------------------------------
            # 모델은 평균(sigma_val)을 받음
            output_sub = self.forward(y1_sub.clamp(0, 1), sigma_val)

            if output_sub.shape[1] == 6:
                denoised_sub = output_sub.chunk(2, dim=1)[0]
            else:
                denoised_sub = output_sub 

            # ---------------------------------------------------
            # 4. 복원 및 누적
            # ---------------------------------------------------
            pred_accum += pixel_shuffle(denoised_sub, self.cfg.r2r.pd_stride)

        pred = pred_accum / float(J)
        pred = torch.clamp(pred, 0.0, 1.0)
        
        self.log("val_psnr", self.psnr(pred, x), prog_bar=True, on_step=False, on_epoch=True)
        self.log("val_ssim", self.ssim(pred, x), prog_bar=False, on_step=False, on_epoch=True)

        if batch_idx == 349: # 349
            # 깔끔하게 내부 메서드 호출!
            self.log_images(x[0:1], y[0:1], pred[0:1])

    def log_images(self, clean, noisy, denoised, key="val_samples"):
        """
        WandB에 이미지를 로깅하는 내부 헬퍼 메서드
        """
        # 로거가 없으면 조기 종료
        if self.logger is None:
            return

        # 1. 텐서 -> Numpy 변환 (CPU 이동 포함)
        def to_np(t):
            return np.clip(t[0].detach().cpu().permute(1, 2, 0).numpy(), 0, 1)

        clean_img = to_np(clean)
        noisy_img = to_np(noisy)
        denoised_img = to_np(denoised)

        # 2. 맵 계산 (Error map, Noise map)
        noise_map = np.abs(noisy_img - clean_img)
        noise_map = (noise_map - noise_map.min()) / (noise_map.max() - noise_map.min() + 1e-8)

        residual_map = np.abs(clean_img - denoised_img)
        # 잘 보이게 Contrast 3배 강조 (선택 사항)
        residual_map = np.clip(residual_map * 3, 0, 1) 

        # 3. Plot 생성
        fig, axes = plt.subplots(1, 5, figsize=(20, 5))
        titles = ["GT", "Noisy", "Noise Pattern", "Result", "Error Map"]
        images = [clean_img, noisy_img, noise_map, denoised_img, residual_map]
        cmaps = [None, None, 'gray', None, 'inferno']

        for ax, img, title, cmap in zip(axes, images, titles, cmaps):
            ax.imshow(img, cmap=cmap)
            ax.set_title(title, fontsize=12)
            ax.axis('off')
        
        plt.tight_layout()

        # 4. WandB 로깅
        try:
            # WandbLogger인지 확인하고 로깅
            if hasattr(self.logger, 'experiment'):
                self.logger.experiment.log({
                    f"{key}/epoch_{self.current_epoch}": [wandb.Image(fig, caption=f"PSNR: {-10*np.log10(((clean_img-denoised_img)**2).mean()):.2f}dB")]
                })
        except Exception as e:
            print(f"Logging failed: {e}")
        finally:
            plt.close(fig) # 메모리 정리

def build_run_name(cfg, version="v1"):
    # args 대신 cfg 객체를 받아서 이름 생성
    return (
        f"{cfg.model.name}_"
        f"a{cfg.r2r.alpha:.2f}_"
        f"img{cfg.data.img_size}_"
        f"stride{cfg.r2r.pd_stride}_"
        f"bs{cfg.data.batch_size}_"
        f"ep{cfg.train.max_epochs}_"
        f"mc{cfg.r2r.mc_samples}_"
        f"{version}"
    )

def main():
    p = argparse.ArgumentParser()
    
    # 1. 런타임 인자 (YAML에 넣기 애매한 실행 시점의 변수들만 남김)
    p.add_argument("--config", type=str, default="exp1.yaml", help="Path to config file")
    p.add_argument("--resume", type=str, default=None, help="Path to checkpoint to resume")
    p.add_argument("--version", type=str, default="v1", help="Experiment version string")
    p.add_argument("--wandb_project", type=str, default="gr2r-denoising")
    p.add_argument("--ckpt_dir", type=str, default="./ckpts_gr2r")

    
    args = p.parse_args()

    # 2. Config YAML 파일 로드
    cfg = OmegaConf.load(args.config)
    
    # (선택) 터미널 명령어로 YAML 설정 덮어쓰기 허용 (예: python main.py --config exp1.yaml r2r.alpha=0.1)
    cfg = OmegaConf.merge(cfg, OmegaConf.from_cli())

    print(f"🚀 Starting Experiment with Config: {args.config}")
    print(OmegaConf.to_yaml(cfg)) # 로드된 설정 터미널에 출력

    # 3. 경로 설정
    train_dir = Path("/workspace02/hyemin/nas/datasets/prep/SIDD_s512_o128")
    val_dir = Path("/workspace02/hyemin/nas/datasets/SIDD")
    
    assert train_dir.exists(), f"Missing: {train_dir}"
    assert val_dir.exists(), f"Missing: {val_dir}"

    # 4. 데이터셋 & 데이터로더 설정 (cfg.data 참조)
    train_ds = SIDDTrainDataset(
        root_dir=train_dir,
        crop_size=cfg.data.img_size
    )
    val_ds = SIDDValidationDataset(
        noisy_file_path=val_dir / "ValidationNoisyBlocksSrgb.mat",
        gt_file_path=val_dir / "ValidationGtBlocksSrgb.mat"
    )

    train_loader = DataLoader(
        train_ds, batch_size=cfg.data.batch_size, shuffle=True,
        num_workers=cfg.data.num_workers, pin_memory=True
    )
    val_loader = DataLoader(
        val_ds, batch_size=1, shuffle=False,
        num_workers=cfg.data.num_workers, pin_memory=True
    )

    # 5. 모델 초기화 (cfg.r2r, cfg.train 등 참조)
    # ※ 만약 PD_GR2R __init__이 cfg 객체 통째로 받도록 수정되었다면 
    # lit_model = PD_GR2R(cfg) 로 한 줄로 끝낼 수 있습니다.
    # 아래는 기존 __init__ 파라미터에 맞춰서 넘겨주는 방식입니다.
    lit_model = PD_GR2R(cfg)

    if cfg.model.checkpoint and str(cfg.model.checkpoint).lower() != "none":
        print(f"[init_weights] loading from: {cfg.model.checkpoint}")
        load_init_weights(lit_model.model, cfg.model.checkpoint, strict=False) 

    # 6. 콜백 및 로거 설정
    ckpt_dir = Path(args.ckpt_dir)
    ckpt_dir.mkdir(parents=True, exist_ok=True)

    callbacks = [
        ModelCheckpoint(
            dirpath=str(ckpt_dir),
            filename="best-psnr-{step:05d}-{val_psnr:.2f}", 
            monitor="val_psnr",
            mode="max",
            save_top_k=1,
        ),
        ModelCheckpoint(
            dirpath=str(ckpt_dir),
            filename="best-ssim-{step:05d}-{val_ssim:.2f}", 
            monitor="val_ssim", 
            mode="max",
            save_top_k=1,
        )
    ]

    # wandb_name = build_run_name(cfg, version=args.version)
    wandb_name = ckpt_dir.name

        
    logger = WandbLogger(
        project=args.wandb_project,
        name=wandb_name,
        save_dir=str(ckpt_dir),   
        log_model=False,
        # W&B에 YAML config 전체를 업로드해서 나중에 하이퍼파라미터 추적하기 쉽게 만들기
        config=OmegaConf.to_container(cfg, resolve=True) 
    )

    # 7. 트레이너 실행
    trainer = L.Trainer(
        max_epochs=-1,
        max_steps=40000,
        accelerator="gpu" if torch.cuda.is_available() else "cpu",
        val_check_interval=200,
        check_val_every_n_epoch=None,
        devices=1,
        gradient_clip_val=1.0,       
        gradient_clip_algorithm="norm", 
        callbacks=callbacks,
        log_every_n_steps=20,
        enable_progress_bar=True,
        logger=logger,
    )

    trainer.fit(lit_model, train_loader, val_loader, ckpt_path=args.resume)

if __name__ == "__main__":
    main()
