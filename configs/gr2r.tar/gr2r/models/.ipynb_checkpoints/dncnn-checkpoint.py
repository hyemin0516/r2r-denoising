import math
import torch
import torch.nn as nn


def weights_init_kaiming(m):
    classname = m.__class__.__name__
    if classname.find("Conv") != -1:
        nn.init.kaiming_normal_(m.weight.data, a=0, mode="fan_in")
        if getattr(m, "bias", None) is not None and m.bias is not None:
            nn.init.constant_(m.bias.data, 0.0)
    elif classname.find("Linear") != -1:
        nn.init.kaiming_normal_(m.weight.data, a=0, mode="fan_in")
        if getattr(m, "bias", None) is not None and m.bias is not None:
            nn.init.constant_(m.bias.data, 0.0)
    elif classname.find("BatchNorm") != -1:
        m.weight.data.normal_(mean=0, std=math.sqrt(2.0 / 9.0 / 64.0)).clamp_(-0.025, 0.025)
        nn.init.constant_(m.bias.data, 0.0)


class DnCNN(nn.Module):
    """
    Minimal DnCNN (no pretrained loading inside model).
    forward(x, sigma=None) kept to be compatible with deepinv-style signatures,
    but sigma is unused.
    """
    def __init__(self, in_channels=3, out_channels=3, depth=20, bias=True, nf=64):
        super().__init__()
        self.depth = int(depth)

        self.in_conv = nn.Conv2d(in_channels, nf, 3, 1, 1, bias=bias)
        self.conv_list = nn.ModuleList(
            [nn.Conv2d(nf, nf, 3, 1, 1, bias=bias) for _ in range(self.depth - 2)]
        )
        self.out_conv = nn.Conv2d(nf, out_channels, 3, 1, 1, bias=bias)
        self.nl_list = nn.ModuleList([nn.ReLU() for _ in range(self.depth - 1)])

        # always random init here
        self.apply(weights_init_kaiming)

    def forward(self, x, sigma=None):
        x1 = self.in_conv(x)
        x1 = self.nl_list[0](x1)
        for i in range(self.depth - 2):
            x1 = self.nl_list[i + 1](self.conv_list[i](x1))
        return self.out_conv(x1) + x
